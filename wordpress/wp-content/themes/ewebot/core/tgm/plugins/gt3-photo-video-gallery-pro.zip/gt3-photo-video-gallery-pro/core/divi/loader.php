<?php

namespace GT3\PhotoVideoGalleryPro\Divi;

defined('ABSPATH') OR exit;

new Modules\Gallery();

