<?php // Silence is golden
